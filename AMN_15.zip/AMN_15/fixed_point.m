function [root, T] = fixed_point(g_func, x0, tol, max_iter)
%FIXED_POINT  Fixed-point iteration x = g(x) (R2018b compatible)

    if nargin < 3, tol = 1e-12; end
    if nargin < 4, max_iter = 200; end

    x = x0;

    iter = zeros(max_iter,1);
    xk   = zeros(max_iter,1);
    dxk  = zeros(max_iter,1);

    for k = 1:max_iter
        xnew = g_func(x);
        dx = abs(xnew - x);

        iter(k) = k;
        xk(k) = xnew;
        dxk(k) = dx;

        if dx < tol
            root = xnew;
            T = table(iter(1:k), xk(1:k), dxk(1:k), ...
                'VariableNames', {'iter','x','abs_dx'});
            return
        end

        x = xnew;
    end

    root = x;
    T = table(iter, xk, dxk, 'VariableNames', {'iter','x','abs_dx'});
end