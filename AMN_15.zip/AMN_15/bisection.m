function [root, T] = bisection(func, a, b, tol, max_iter)
%BISECTION  Bisection method for f(x)=0 (R2018b compatible)

    if nargin < 4, tol = 1e-12; end
    if nargin < 5, max_iter = 100; end

    fa = func(a);
    fb = func(b);

    if fa == 0
        root = a;
        T = table(0, a, b, a, fa, (b-a)/2, ...
            'VariableNames', {'iter','a','b','c','f_c','half_width'});
        return
    elseif fb == 0
        root = b;
        T = table(0, a, b, b, fb, (b-a)/2, ...
            'VariableNames', {'iter','a','b','c','f_c','half_width'});
        return
    end

    if fa*fb > 0
        error('Bisection:BadBracket', ...
            'f(a) and f(b) must have opposite signs. Got f(a)=%.16g, f(b)=%.16g.', fa, fb);
    end

    iter = zeros(max_iter,1);
    ak   = zeros(max_iter,1);
    bk   = zeros(max_iter,1);
    ck   = zeros(max_iter,1);
    fck  = zeros(max_iter,1);
    hw   = zeros(max_iter,1);

    for k = 1:max_iter
        c = (a + b)/2;
        fc = func(c);

        iter(k) = k;
        ak(k) = a;
        bk(k) = b;
        ck(k) = c;
        fck(k) = fc;
        hw(k) = (b - a)/2;

        if abs(fc) < tol || hw(k) < tol
            root = c;
            T = table(iter(1:k), ak(1:k), bk(1:k), ck(1:k), fck(1:k), hw(1:k), ...
                'VariableNames', {'iter','a','b','c','f_c','half_width'});
            return
        end

        if fa*fc < 0
            b = c;
            fb = fc;
        else
            a = c;
            fa = fc;
        end
    end

    root = (a + b)/2;
    T = table(iter, ak, bk, ck, fck, hw, ...
        'VariableNames', {'iter','a','b','c','f_c','half_width'});
end