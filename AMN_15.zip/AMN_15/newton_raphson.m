function [root, T] = newton_raphson(func, dfunc, x0, tol, max_iter)
%NEWTON_RAPHSON  Newton's method for f(x)=0 (R2018b compatible)

    % Default values if not provided (simple check for R2018b)
    if nargin < 4, tol = 1e-12; end
    if nargin < 5, max_iter = 50; end

    x = x0;

    iter = zeros(max_iter,1);
    xk   = zeros(max_iter,1);
    fxk  = zeros(max_iter,1);
    dxk  = zeros(max_iter,1);

    for k = 1:max_iter
        fx = func(x);
        dfx = dfunc(x);

        if dfx == 0
            error('Newton-Raphson:ZeroDerivative', ...
                  'Derivative is zero at iteration %d (x = %.16g).', k, x);
        end

        xnew = x - fx/dfx;
        dx = abs(xnew - x);

        iter(k) = k;
        xk(k)   = xnew;
        fxk(k)  = func(xnew);
        dxk(k)  = dx;

        if abs(fxk(k)) < tol || dx < tol
            root = xnew;
            % Create table
            T = table(iter(1:k), xk(1:k), fxk(1:k), dxk(1:k), ...
                'VariableNames', {'iter','x','f_x','abs_dx'});
            return
        end

        x = xnew;
    end

    root = x;
    T = table(iter, xk, fxk, dxk, 'VariableNames', {'iter','x','f_x','abs_dx'});
end