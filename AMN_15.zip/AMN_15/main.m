% main_script.m
% Water trough: semicircular cross-section (R2018b compatible)

clear; clc;
format long

% -----------------------------
% Given data
% -----------------------------
r = 1;          % ft
L = 10;         % ft
V_target = 12.4; % ft^3

% -----------------------------
% Geometry
% -----------------------------
% Area as a function of depth h
A = @(h) r^2*acos((r - h)./r) - (r - h).*sqrt(2*r*h - h.^2);
V = @(h) L*A(h);

% Functions for root finding
f  = @(h) V(h) - V_target;
df = @(h) 2*L*sqrt(2*r*h - h.^2);

% Fixed-point g(h) = h - f(h)/(2*L*r)
g = @(h) h - f(h)/(2*L*r);

% -----------------------------
% Method settings
% -----------------------------
tol_newton = 1e-12;   % required accuracy
tol_other  = 1e-12;
max_iter   = 200;

% Initial guesses
x0 = 0.85; 
a  = 0.0;
b  = r;

% -----------------------------
% Run methods
% -----------------------------
% These call the files you just created
[hN, TN] = newton_raphson(f, df, x0, tol_newton, max_iter);
[hB, TB] = bisection(f, a, b, tol_other, max_iter);
[hF, TF] = fixed_point(g, x0, tol_other, max_iter);

% -----------------------------
% Report Results
% -----------------------------
fprintf('Semicircular trough: r = %.4f, L = %.4f, V_target = %.4f\n', r, L, V_target);
fprintf('------------------------------------------------------------\n');

fprintf('Newton-Raphson Result:\n');
fprintf('  Depth h = %.15f ft\n', hN);
fprintf('  Iterations: %d\n', height(TN));
fprintf('  Volume check: %.15f ft^3\n\n', V(hN));

fprintf('Bisection Result:\n');
fprintf('  Depth h = %.15f ft\n', hB);
fprintf('  Iterations: %d\n\n', height(TB));

fprintf('Fixed-Point Result:\n');
fprintf('  Depth h = %.15f ft\n', hF);
fprintf('  Iterations: %d\n', height(TF));